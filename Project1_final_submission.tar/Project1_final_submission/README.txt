﻿Kalpesh Chavan & Hieu Nguyen


MyMalloc.h:


Function definitions:
* void *mymalloc(int size, int line, char* file)
* void myfree(void* ptr, int line, char* file)


Macros:
* #define malloc(x) mymalloc(x, __FILE__, __LINE__)
* #define free(x) myfree(x, __FILE__, __LINE__)


The header struct:


typedef struct header
{
    size_t size;
    int is_occupied;
} HEADER;


Explanation:


The function definitions build on the traditional implementations of C’s malloc and free methods by asking the caller to enter a line number and a file name. These additional parameters enable verbose error reporting from within the scope of the implementations of the methods (found in mymalloc.c). 


The macros from within the header file implicitly overwrite any traditional calls to malloc and free (which typically take a single parameter) with calls to our malloc and free implementations (mymalloc and myfree) and pass these calls the FILE name and LINE number associated with any given call. It is important that this header file is included after the “#include <stdio.h> ” line for the macros to effectively overwrite C’s built-in malloc and free functions.






MyMalloc.c:


Function definitions:
* coalesce()
* my_malloc()
* my_free()
* initialized_memory_add()
* free_valid_pointer()
* memory_is_empty()


Macros:
* MEMLENGTH
   * Used as a constant for the size of memory array
* MEMLENGTH_BYTES
   * Used to to calculate the memory length in terms of byte size
* HEADER_SIZE
   * Used as a constant for the size of meta-data and header prior to data
* ROUNDUP(X)
   * Used as a macro for rounding up uneven sizes of data


Coalesce():
        We use coalesce to merge adjacent free blocks to create a larger individual block.
        
We do this by iterating through every header and checking for free headers followed by other free headers.
If this is true, we merge the header with the proceeding header. We then keep the current and iterate to the following chunk by utilizing the updated size in accordance to allow for further adjacent frees.


If the next adjacent header is not free, we move the current header to it, and make the next header point to the chunk after the updated current pointer, and continue the loop.


my_malloc():
We use my_malloc to add data and headers into the memory, as well as checking for data availability and validity of the introduced data.


We first check that the introduced data is valid by:
* Ensuring the data is not 0, as we cannot introduce 0 data to memory
   * We don’t exit program because it does not damage the memory array, and we just reject the input. If somehow we were to allow it, it would cause more complications
* The size of data is not larger than the size of memory
   * We don’t exit the program because the data is inherently unusable and cannot be inputted if we wanted to.
* In theory it is possible to have a header address 0 bytes of memory but this option was considered impractical and a waste of space. Since the header still takes up 8 bytes of precious space on its own.




        We begin adding the data by first checking that the memory is not initialized:
                If it is not initialized, we create a new header and add the block.
We then check that there is enough size afterward to add a minimum sized ending header
        If there is space then the header is added, otherwise we return


        If the memory array is initialized:
We create a new header and use the support function: initialized_memory_add() to set the header


If the new header is not NULL, then we return. Otherwise, we print an error and return NULL.
We return null because in this case, there is simply not enough space in the memory array, and we do not exit since the data is unusable in the first place


initialized_memory_add():
This is used as a support function for my_malloc() to check and add data to the memory array


We first create a return header and a running “next” header, and a running “current” header that begins at the start of the memory array


We first check that the beginning header is not taking the entire memory array, and set the “next” header accordingly


We then keep a running “current_byte” to iterate through a loop that checks if the “current” byte is occupied and if the size of it fits the introduced data.
If the header is not occupied, and the space fits, we add the data and initialize the ending header, and return.


Otherwise we move onto the next header and check that one.


We continue the loop based if the current_byte is still under the total memory array size, and that the current header is less than the memory array + its size.
my_free():
        This function de-allocates data from the memory array.
        
        We first check that the memory array is initialized
                If it is not, we send an error and return. 
We do not exit because using free on an unitialized memory array does not pose any threat since there is no data to be modified in the first place


We then need to check that the given pointer exists within the array by iterating through it and checking if the given pointer matches at any point
                If the pointer is not within the array, we send an error and return.
We do not exit because the location of the pointer does not exist anywhere within the memory array, so nothing can be called upon to affect the array


If the pointer is valid, we then use an int and set it using the support function free_valid_pointer()
        If the value returns correctly, then the data was successfully freed


Otherwise, we print error and return.
We do not exit because the pointer arithmetic is incorrect and must reset the position at the next free


free_valid_pointer():
        This function checks whether the pointer given by the client is actually safe to free. There are three cases in which the pointer is considered unsafe:


* If the pointer points to memory that has already been freed
* If the pointer points in the array, but not to a valid location (valid locations are those returned by my_malloc, which are pointers to the byte directly after a header).
* If the pointer exists completely outside the scope of the array.


We check for the case of a double free by iterating through the memory array header to header. At each iteration we check if the given pointer, ptr, is equal to a pointer to the memory references a location in memory that is directly after the header (a valid location that could have been returned by malloc) if the pointers are equal we have two cases:


* If the memory block is free (as indicated by the header) and the pointers are equal, then the user has attempted to free memory that is already free.
* If the memory block is occupied (as indicated by the current header) and the pointers are equal then we simply free the memory (success).


After the while loop we return a -1 which indicates that either the pointer is not in the memory array (which we should have accounted for before calling free_valid_pointer()) or the location is within the array, but not in a valid position (which is what the -1 output will indicate within the context of my_free).
We do not exit because the reference to free is to something that was already freed, thus the data was already intended to be removed and wil not cause damage
memory_is_empty():
        This function checks if the memory array is empty, an array may be empty but initialized but an uninitialized array is always considered empty. To check if an array is empty, we simply check the status of the first header. 


* If the first header points to the rest of memory (has a size of 4088) and is not occupied then the entire memory has been properly coalesced and is empty. We return 1.


* If the first header has a size of 0, then the memory must not have been initialized as the only way the leading header can have a size of 0, is in the case of an uninitialized array. Since the memory is uninitialized we treat it as empty and return 1.


* In all other cases we return a 0.






MemGrind:


Function definitions:
* test1()
* test2()
* test3()
* test4()
* test5()
* test_looper(int test_number)


main():
Runs support function test_looper() for all 5 test functions and check that memory array is fully cleared after each test


test_looper(int test_number):
        Support function that loops and times a test 50 times, and gets the average time


We loop 50 times:
We begin the timer
We use a switch case using the given test_number to do the specified test
                End the timer and print the time taken
                Add the amount of time to the total time
        We then print the average time
        
test1():
        The first test given from the documentation
        
        Loop 120 times:
                Allocate data with a 1-byte size


test2():
        Create a pointer array of size 120


        Loop 120 times and allocate 120 blocks of data with byte size 1


        Loop 120 times and free each block


test3():
makes array of 120 pointers, randomly allocates or frees pointers until 120 are allocated


test4():
        Makes an array of 120 pointers to allocated portions in the memory.
        
Then frees every other pointer, so there is a pattern of occupied and free data blocks


Then free the remaining pointers, forcing a double sided coalesce for every free that is not the first or last pointer


test5():
        We exponentially increase the number of blocks to allocate


We create a variables:
* chunk_size = 4096 (represents the size of each block)
* n_allocations = 1 (represents the number of times permitted to allocate)
* counter = 0 (represents the number of times we’ve allocated and freed)


We then create a pointer array of size 256 because at the deepest level, there will be at most 256 allocated pointers


We then loop until the chunk size is less than or equal to the minimum size of data and header combined (minimum chunk size).


We then allocate pointers equal to the chunk size  - 8 into the pointer array and then free them. Chunk size should be the size of the entire chunk so the - 8 accounts for the header portion.


The two inner for loops allocate n chunks of size chunk_size and free them respectively. By the deepest iteration (where counter becomes 9), ptr_array should be filled completely, because there can be at most 256 allocated chunks of size 16 in the memory array.


We then double the n_allocations size and halve the chunk size, and increase the counter by 1 for each iteration of the outermost loop. 


We then print the number of times iterated once we are done looping and reach the minimum size for data and headers